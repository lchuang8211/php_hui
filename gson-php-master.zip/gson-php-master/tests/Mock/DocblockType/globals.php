<?php

namespace {
    class MyGlobalClassMock {}
}

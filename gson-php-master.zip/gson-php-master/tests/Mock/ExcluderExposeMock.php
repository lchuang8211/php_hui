<?php
/*
 * Copyright (c) Nate Brunette.
 * Distributed under the MIT License (http://opensource.org/licenses/MIT)
 */

namespace Tebru\Gson\Test\Mock;

use Tebru\Gson\Annotation\Expose;

/**
 * @Expose(deserialize=false)
 */
class ExcluderExposeMock
{
}

<?php
/*
 * Copyright (c) Nate Brunette.
 * Distributed under the MIT License (http://opensource.org/licenses/MIT)
 */

namespace Tebru\Gson\Test\Mock;

/**
 * interface TypeAdapterMockable
 *
 * @author Nate Brunette <n@tebru.net>
 */
interface TypeAdapterMockable
{

}
